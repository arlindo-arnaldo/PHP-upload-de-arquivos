<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Upload</title>
      <style>
          *{
            padding:0px;   
            margin:0px;
            font-family: consolas;
          }
          .box{
            display: block;
            border: 1px solid #ccc;
            padding:60px 0px;
            width:40%;
            margin:10% auto;
            text-align:center;
            border-radius: 10px;
            box-shadow: 2px 2px 15px #cdcdcd;
          }
          .msg{
            
            width:180px;
            display: block;
            margin:5px auto;
            padding: 10px 10px;
            border-radius: 10px;
            color: white;
          }
          .erro{
            background-color: rgb(145, 36, 36);
          }
          .sucesso{
            background-color: rgb(42, 95, 53);
          }
      </style>
  </head>
  <body> 
  <!-- Criando da box principal onde serão apresentados os elementos -->
    <div class="box">

      <!-- Criando o alert para mensagens de erro -->
      <?php
      if (!isset($_SESSION['erro']) && !isset($_SESSION['sucesso'])) {
        echo " <h2>Selecione um arquivo</h2>";
      }
        #Verifica se está chegando algum erro, e imprime na tela
        if (isset($_SESSION['erro']) && !empty($_SESSION['erro'])) {
            if (isset($_SESSION['erro-detalhe'])) {
              echo $_SESSION['erro-detalhe'];
            }
          ?>
          <div class="msg erro">
            <?= $_SESSION['erro']; ?>
          </div>
          <?php
          #Destroi a mensagem de erro
          unset($_SESSION['erro']);
          unset($_SESSION['erro-detalhe']);
        }
        #Verifica se está chegando alguma mensagem de sucesso, e imprime na tela
        if (isset($_SESSION['sucesso']) && !empty($_SESSION['sucesso'])) {
      ?>
      <!-- Criando o alert para mensagens de sucesso -->
      <div class="msg sucesso">
      <?= $_SESSION['sucesso']; ?>
     </div>
     <?php
        echo " <br>";
        unset($_SESSION['sucesso']);
      }
      
     ?>
      <br>   
      <!-- Adicionando o formulário para envio do arquivo -->
    <!-- O arquivo será enviado para "upload.php"  -->
    <form action="upload.php" method="post" enctype="multipart/form-data">
      <input type="file" name="arquivo">
      <input type="submit" value="Enviar">
    </form>

    </div><!--Fim da box-->
  
  </body>
</html>
