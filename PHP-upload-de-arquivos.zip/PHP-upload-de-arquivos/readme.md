# PHP-upload-de-arquivos
Para implementar  o algoritmo, basta fazer algumas alterações no cógido fonte do arquivo upload.php.

Faça as seguintes  alterações:

    1- Você pode mudar o tamanho máximo de upload alterando o valor da define('TAMANHO_MAXIMO', (seuvalor * 1024 * 1024 ))
    2- Altere também o directório de destino, mudando o valor da define('PASTA', 'sua pasta')
    3- Opcionalmente pode remover da linha 21 até a linha 26, para permitir o upload de todos tipos arquivos.

Escrito por:
Arlindo Arnaldo Cassuende

facebook.com/arlindoacassuende
linkedin.com/in/arlindo-arnaldo-cassuende