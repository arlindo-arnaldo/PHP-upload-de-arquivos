<?php
session_start();

if (!isset($_FILES['arquivo']) || empty($_FILES['arquivo'])) {
  $_SESSION['erro'] = "Selecione um arquivo e tente novamente!";
  header("Location: index.php");
  die();
}
#Definindo o tamanho máximo de upload como 5MB
define('TAMANHO_MAXIMO', (5*1024*1024));
#Definindo o local onde o arquivo será salvo
define('PASTA', 'arquivos');

#Verificando se o arquivo enviado pelo formulário está chegado correctamente
if ($_FILES['arquivo']['error'] !== UPLOAD_ERR_OK) {
    $_SESSION['erro'] = "Ocorreu um erro no upload do arquivo.";
    header("Location: index.php");
    die();
}

#(OPCIONAL) Restringindo o envio apenas para arquivo pdf (OPCIONAL)
if ($_FILES['arquivo']['type'] !== 'application/pdf') {
    $_SESSION['erro'] = "O arquivo enviado não é um pdf.";
    header("Location: index.php");
    die();
}

#Verificando se o arquivo não Excede 5Mb
if ($_FILES['arquivo']['size'] > TAMANHO_MAXIMO) {
  $_SESSION['erro'] = "O arquivo é muito grande";
  $_SESSION['erro-detalhe'] = "Envie apenas arquivos com menos de 5MB";
  header("Location: index.php");
  die();
}

#Renomeando o arquivo com base o time do upload
#Evitando arquivos com mesmo nome

$filename = time() . '_' . $_FILES['arquivo']['name'];

#Executando o envio do arquivo, dentro do directório  "arquivos" no servidor
if (!move_uploaded_file($_FILES['arquivo']['tmp_name'], PASTA.'/' . $filename)) {
  $_SESSION['erro'] = "Não foi possível salvarr o arquivo no servidor.";
  die();
} 
#Enviando a mensagem de sucesso
$_SESSION['sucesso'] = "O arquivo foi enviado com sucesso.";
#Redirecionando para a página index.php
header("Location: index.php");

